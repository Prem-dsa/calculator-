export function calculate(a: string, b: string, operator: string): string {
  const num1 = parseFloat(a);
  const num2 = parseFloat(b);

  switch (operator) {
    case '+':
      return String(num1 + num2);
    case '-':
      return String(num1 - num2);
    case '×':
      return String(num1 * num2);
    case '÷':
      if (num2 === 0) return 'Error';
      return String(num1 / num2);
    default:
      return String(num2);
  }
}