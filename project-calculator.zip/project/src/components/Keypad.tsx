import React from 'react';
import { Button } from './Button';

interface KeypadProps {
  onNumberClick: (num: string) => void;
  onOperatorClick: (op: string) => void;
  onEqualsClick: () => void;
  onClearClick: () => void;
}

export function Keypad({
  onNumberClick,
  onOperatorClick,
  onEqualsClick,
  onClearClick,
}: KeypadProps) {
  return (
    <div className="grid grid-cols-4 gap-2">
      <Button onClick={onClearClick} variant="secondary">C</Button>
      <Button onClick={() => onOperatorClick('±')} variant="secondary">±</Button>
      <Button onClick={() => onOperatorClick('%')} variant="secondary">%</Button>
      <Button onClick={() => onOperatorClick('÷')} variant="primary">÷</Button>

      <Button onClick={() => onNumberClick('7')}>7</Button>
      <Button onClick={() => onNumberClick('8')}>8</Button>
      <Button onClick={() => onNumberClick('9')}>9</Button>
      <Button onClick={() => onOperatorClick('×')} variant="primary">×</Button>

      <Button onClick={() => onNumberClick('4')}>4</Button>
      <Button onClick={() => onNumberClick('5')}>5</Button>
      <Button onClick={() => onNumberClick('6')}>6</Button>
      <Button onClick={() => onOperatorClick('-')} variant="primary">-</Button>

      <Button onClick={() => onNumberClick('1')}>1</Button>
      <Button onClick={() => onNumberClick('2')}>2</Button>
      <Button onClick={() => onNumberClick('3')}>3</Button>
      <Button onClick={() => onOperatorClick('+')} variant="primary">+</Button>

      <Button onClick={() => onNumberClick('0')} className="col-span-2">0</Button>
      <Button onClick={() => onNumberClick('.')}>.</Button>
      <Button onClick={onEqualsClick} variant="primary">=</Button>
    </div>
  );
}