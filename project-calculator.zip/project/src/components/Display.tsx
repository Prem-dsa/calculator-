import React from 'react';

interface DisplayProps {
  value: string;
  currentValue: string;
}

export function Display({ value, currentValue }: DisplayProps) {
  return (
    <div className="bg-gray-800 rounded-lg p-4 mb-4">
      <div className="text-gray-400 text-right text-sm h-6 mb-1">
        {value || '\u00A0'}
      </div>
      <div className="text-white text-right text-3xl font-semibold">
        {currentValue || '0'}
      </div>
    </div>
  );
}