import React from 'react';
import { cn } from '../utils/cn';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'primary' | 'secondary';
  children: React.ReactNode;
}

export function Button({
  variant = 'default',
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        'h-14 rounded-lg text-xl font-medium transition-colors',
        {
          'bg-gray-700 text-white hover:bg-gray-600': variant === 'default',
          'bg-orange-500 text-white hover:bg-orange-400': variant === 'primary',
          'bg-gray-600 text-white hover:bg-gray-500': variant === 'secondary',
        },
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}