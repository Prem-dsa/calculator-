import React from 'react';
import { Display } from './Display';
import { Keypad } from './Keypad';
import { useCalculator } from '../hooks/useCalculator';

export function Calculator() {
  const {
    display,
    currentValue,
    handleNumberClick,
    handleOperatorClick,
    handleEqualsClick,
    handleClearClick,
  } = useCalculator();

  return (
    <div className="w-80 bg-gray-900 rounded-2xl shadow-2xl p-6">
      <Display value={display} currentValue={currentValue} />
      <Keypad
        onNumberClick={handleNumberClick}
        onOperatorClick={handleOperatorClick}
        onEqualsClick={handleEqualsClick}
        onClearClick={handleClearClick}
      />
    </div>
  );
}