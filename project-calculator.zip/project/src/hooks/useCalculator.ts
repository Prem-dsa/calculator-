import { useState } from 'react';
import { calculate } from '../utils/calculate';

export function useCalculator() {
  const [display, setDisplay] = useState('');
  const [currentValue, setCurrentValue] = useState('');
  const [operator, setOperator] = useState('');
  const [previousValue, setPreviousValue] = useState('');
  const [newNumber, setNewNumber] = useState(true);

  const handleNumberClick = (num: string) => {
    if (newNumber) {
      setCurrentValue(num);
      setNewNumber(false);
    } else {
      setCurrentValue(currentValue + num);
    }
  };

  const handleOperatorClick = (op: string) => {
    if (op === '±') {
      setCurrentValue(String(-parseFloat(currentValue || '0')));
      return;
    }

    if (op === '%') {
      setCurrentValue(String(parseFloat(currentValue || '0') / 100));
      return;
    }

    setNewNumber(true);
    
    if (previousValue && operator && !newNumber) {
      const result = calculate(previousValue, currentValue, operator);
      setCurrentValue(result);
      setDisplay(`${result} ${op}`);
      setPreviousValue(result);
    } else {
      setDisplay(`${currentValue} ${op}`);
      setPreviousValue(currentValue);
    }
    
    setOperator(op);
  };

  const handleEqualsClick = () => {
    if (!operator || !previousValue) return;

    const result = calculate(previousValue, currentValue, operator);
    setDisplay('');
    setCurrentValue(result);
    setPreviousValue('');
    setOperator('');
    setNewNumber(true);
  };

  const handleClearClick = () => {
    setDisplay('');
    setCurrentValue('');
    setPreviousValue('');
    setOperator('');
    setNewNumber(true);
  };

  return {
    display,
    currentValue,
    handleNumberClick,
    handleOperatorClick,
    handleEqualsClick,
    handleClearClick,
  };
}